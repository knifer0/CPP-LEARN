//
// Created by Papaj on 2019-07-22.
//

#include "event.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
void czysc(){
    char ch;
    while((ch = getchar()) != '\n')
        continue;
}
extern int IloscObiektow;
Event::Event(){
    dodaj_wydarzenie();
}; // pusty konstruktor ! ;) --> wywołuje on inną metodę tej klasy 
void Event::dodaj_wydarzenie() {
    cout<<"Podaj nazwe wydarzenia: ";
    getline(cin,nazwa_wydarzenia);
    cout<<"Podaj dzien wydarzenia: ";
    cin>>dzien_wydarzenia;
    czysc();
    cout<<"Podaj nazwe miesiaca: ";
    getline(cin,nazwa_miesiaca);
    cout<<"Podaj rok wydarzenia: ";
    cin>>rok_wydarzenia;
    czysc();
    cout<<"Podaj godzine: ";
    cin>>godzina;
    czysc();
    cout<<"Podaj minuty: ";
    cin>>minuty;
    czysc();
}
Event::Event(string nw, unsigned int dw, string nm, unsigned int rw, int g, int min){
    nazwa_wydarzenia=nw;
    dzien_wydarzenia=dw;
    nazwa_miesiaca=nm;
    rok_wydarzenia=rw;
    godzina=g;
    minuty=min;
    IloscObiektow++;
}
Event::~Event(){
    cout << "To ja. Destruktor sie nazywam" << endl;
    IloscObiektow--;
}

void Event::wyswietl_wydarzenie() {
    cout <<"Nazwa: "<< nazwa_wydarzenia<<endl;
    cout<< dzien_wydarzenia <<" " << nazwa_miesiaca << " " << rok_wydarzenia<<" "<<godzina<<":"<<minuty<<endl;
}