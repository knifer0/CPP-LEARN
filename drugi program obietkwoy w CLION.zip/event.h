//
// Created by Papaj on 2019-07-22.
//
#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;

#ifndef UNTITLED1_EVENT_H
#define UNTITLED1_EVENT_H


class Event {
    string nazwa_wydarzenia;
    unsigned int dzien_wydarzenia;
    string nazwa_miesiaca;
    unsigned int rok_wydarzenia;
    int godzina,minuty;
public:
    void dodaj_wydarzenie();
    void wyswietl_wydarzenie();
    Event(void);
    Event(string nw, unsigned int dw, string nm, unsigned int rw, int g, int min );
    Event(unsigned int dw, string nw, string nm, unsigned int rw, int g, int min );
    ~Event();
};


#endif //UNTITLED1_EVENT_H
