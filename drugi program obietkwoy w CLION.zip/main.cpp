#include <iostream>
#include "event.h"
int IloscObiektow=0;
using std::cout;
using std::cin;
using std::endl;
using std::string;
int main() {
    Event w1("Bitwa pod Grunwaldem",15,"lipca",1410,12,00);
    Event w2;
    cout<<endl<<IloscObiektow<<endl;
    return 0;
}