#include <iostream>
#include "templatee.h"
using std::cout;
using std::cin;
using std::endl;
using std::string;
void sedzia(Punkt &p1, Prostokat &p2);
int main() {
    Punkt point_one("A",3,5);
    Prostokat prostokat_one("Prostokat",1,1,2,4);
   // point_one.wczytaj_punkt();
   // prostokat_one.wczytaj_prostokat();
    prostokat_one.sedzia(point_one);
    return 0;
}
