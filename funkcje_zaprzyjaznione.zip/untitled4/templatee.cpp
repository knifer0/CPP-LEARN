//
// Created by Papaj on 2019-07-23.
//

#include "templatee.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
Punkt::Punkt(string n, float q, float p) {
    nazwa=n;
    x=q;
    y=p;
}
Prostokat::Prostokat(string n, float q, float p, unsigned int szer, unsigned int wys) {
    nazwa=n;
    x=q;
    y=p;
    szerokosc=szer;
    wysokosc=wys;
}
void Punkt::wczytaj_punkt() {
    cout <<"Podaj nazawe punktu: ";
    cin >> nazwa;
    cout << "Podaj wspolrzedna x punktu: ";
    cin >>x;cout << "Podaj wspolrzedna y punktu: ";
    cin >>y;
}
void Prostokat::wczytaj_prostokat() {
    cout <<"Podaj nazawe prostokata: ";
    cin >> nazwa;
    cout << "Podaj wspolrzedna x punktu: ";
    cin >>x;
    cout << "Podaj wspolrzedna y punktu: ";
    cin >>y;
    cout << "Podaj szerokosc prostokata: ";
    cin >>szerokosc;
    cout << "Podaj wysokosc prostokata: ";
    cin >>wysokosc;
}
void Prostokat::sedzia(Punkt &p1) {
    if(p1.x>=x && p1.x<=x + szerokosc && p1.y>=y && p1.y<=y+wysokosc)
        cout <<"Punkt "<< p1.nazwa <<" nalezy do prostokata " <<nazwa <<endl;
    else
        cout <<"NIE NALEZY" <<endl;
}