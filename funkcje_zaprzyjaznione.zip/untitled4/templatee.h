//
// Created by Papaj on 2019-07-23.
//
// zadanie: zrobic tak, zeby funkcja sedzia byla metoda klasy Prostokat, a nie funkcja z main
//1 sposób: zrobienie tak, żeby klasa Prostokat była przyjacielem klasy Punkt

#ifndef UNTITLED4_TEMPLATEE_H
#define UNTITLED4_TEMPLATEE_H
#include <iostream>
using std::string;
class Prostokat;
class Punkt {
    float x,y;
    friend class Prostokat;
    string nazwa;
public:
    Punkt(string="brak", float=0, float=0);
    void wczytaj_punkt();
};

class Prostokat{
    float x,y;
    string nazwa;
    unsigned int szerokosc,wysokosc;
public:
    Prostokat(string="Prostokat", float=0, float=0, unsigned int=1, unsigned int=1);
    void wczytaj_prostokat();
    void sedzia(Punkt &p1);

};


#endif //UNTITLED4_TEMPLATEE_H
