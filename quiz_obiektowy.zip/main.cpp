#include <iostream>
#include <fstream>
#include <cstdlib>
#include <windows.h>
#include "template.h"
using namespace std;
using std::cout;
using std::cin;
using std::endl;
using std::string;
using namespace std;
void linia(void){
    for(int i=0; i<40; i++)
        cout<<"-";
    cout<<endl;
}
fstream fp;
int main() {
    fp.open("quiz.txt",ios::in);
    if(!(fp.good())){
        cout <<"Nie ma takiego pliku";
        exit(EXIT_FAILURE);
    }
    linia();
    string witamy[2];
    getline(fp,witamy[0]);
    getline(fp,witamy[1]);
    cout<<witamy[0]<<endl<<witamy[1]<<endl;
    linia();
    Pytanie zbior_pytan[5];
    for(int i=0; i<5; i++){
        zbior_pytan[i].wczytaj();
        zbior_pytan[i].wyswietl();
        zbior_pytan[i].udziel_odpowiedz();
        zbior_pytan[i].sprawdz_odpowiedz();
    }
    fp.close();
    return 0;
}