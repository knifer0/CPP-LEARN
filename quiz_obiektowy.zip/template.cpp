//
// Created by Papaj on 2019-07-21.
//
#include <iostream>
#include "template.h"
#include <windows.h>
#include <fstream>
using std::cout;
using std::cin;
using std::endl;
extern std::fstream fp;
using namespace std;
    void Pytanie::wczytaj(){
        getline(fp,tresc);
        getline(fp,odpA);
        getline(fp,odpB);
        getline(fp,odpC);
        getline(fp,odpD);
        getline(fp,poprawna);

    }
    void Pytanie::wyswietl(){
        cout<< tresc << endl << "a." << odpA<<endl << "b. " << odpB<<endl << "c. "<< odpC<<endl << "d. "<<odpD<<endl;
    }
    void Pytanie::udziel_odpowiedz(){
        cout <<"Podaj odpowiedz: ";
        cin>>twoja_odpowiedz;
    }
    void Pytanie::sprawdz_odpowiedz(){
        if(twoja_odpowiedz==poprawna){
            cout<<"To poprawna odpowiedz!"<<endl;
        }
        else
            cout<<"Odpowiedz jest niepoprawna"<<endl;
        Sleep(2000);
    }
