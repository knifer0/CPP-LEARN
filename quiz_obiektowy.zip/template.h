//
// Created by Papaj on 2019-07-21.
//

#ifndef UNTITLED106_TEMPLATE_H
#define UNTITLED106_TEMPLATE_H
using std::string;
using namespace std;
class Pytanie{
public:
    string tresc, odpA, odpB, odpC, odpD;
    int punkty;
    string poprawna, twoja_odpowiedz;

    void wczytaj();

    void wyswietl();

    void udziel_odpowiedz();

    void sprawdz_odpowiedz();
};
#endif //UNTITLED106_TEMPLATE_H
