#include <iostream>
#include <vector>
#include <array>
const int ilosc=10;
int main(void){
	std:: vector<std::string> tab(ilosc);
	std:: array<std::string,ilosc> tab2;
	return 0;
}
